
<?php if(@$_SESSION[_HIVE_SITE_COOKIE_."hive_dashboard_subtheme"] == "dark") { ?>
	/******************************************************* dark Table Style for Datatables  *********/
	.x_class_table_label {
		color: #CCCCCC ;
	}
<?php } ?>
<?php
 echo "100";
?>